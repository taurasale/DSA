def status(Name=None):
  if Name == None:
    print('Hello world')
  else:
    print(f'hello {Name}')
