import setuptools
setuptools.setup(
 name='taurokalkasv3',
 version='0.3',
 author="tauras",
 author_email="tauro@gmail.com",
 description="tau",
 packages=setuptools.find_packages(),
 classifiers=[
 "Programming Language :: Python :: 3",
 "License :: OSI Approved :: MIT License",
 "Operating System :: OS Independent"],
 long_description="""# Markdown supported!\n\n* Cheer\n* Celebrate\n""",
 long_description_content_type='text/markdown',
)