from setuptools import setup

setup(
  name='Tauras123123123123',
  version='0.0.1',
  description = 'Say hello!',
  py_modules=['main'],
  package_dir={' ':'src'},
)